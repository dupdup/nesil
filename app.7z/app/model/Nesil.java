package model;

public class Nesil {
	private String nesil;

	public Nesil(String nesil) {
		super();
		this.nesil = nesil;
	}

	public String getNesil() {
		return nesil;
	}

	public void setNesil(String nesil) {
		this.nesil = nesil;
	}
}
