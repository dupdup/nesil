/**
 * ExportService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.isurveysoft.www.servicesv5;

public interface ExportService extends javax.xml.rpc.Service {
    public java.lang.String getExportServiceSoapAddress();

    public com.isurveysoft.www.servicesv5.ExportServiceSoap getExportServiceSoap() throws javax.xml.rpc.ServiceException;

    public com.isurveysoft.www.servicesv5.ExportServiceSoap getExportServiceSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
